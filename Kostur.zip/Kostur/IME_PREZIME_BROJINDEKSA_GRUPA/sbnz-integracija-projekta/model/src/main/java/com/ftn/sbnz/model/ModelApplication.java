package com.ftn.sbnz.model;

public class ModelApplication {

	public static void main(String[] args) {
		System.out.println("Hello from model!");
	}

}
